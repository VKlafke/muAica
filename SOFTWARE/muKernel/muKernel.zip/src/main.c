#include "muKernel.h"


volatile int count = 0x666;



void BDPort_Setup(int config, int enable, int intr)
{
	__asm__ volatile 
	("addi a7, x0, 10 \n\t" \
	 "ecall \n\t");
}

int BDPort_Read()
{
	int retVal = 0;
	
	__asm__ volatile 
	("addi a7, x0, 11 \n\t" \
	 "ecall \n\t" \
	 "mv %0, a0"
	 : "=r" (retVal)
	 );

	return retVal;	 
}

int main()
{	
	////////////////////////////////////////
	//  								  //
	//  Configure the bidirectional port  //
	//	
	//  Enable: 0xF000000F, last and first 4 bits are enabled
	//	Config: 0xF000000F, last and first 4 bits are input
	//	  INTR: 0xF0000000, last 4 bits are connected to PIC  
	////////////////////////////////////////
	
	
	BDPort_Setup(0xF000000F, 0xF000000F, 0xF0000000);
	
	//
	
	// port config, first eight bits are input / interrupt
	/**(int*)BDPORT_CFG = 0xF0000000;
	
	// port enable
	*(int*)BDPORT_EN = 0xFFFFFFFF;

	// zero out port
	*(int*)BDPORT_DATA = 0;
	
	*(int*)BDPORT_EN   = 0xF0000000;
	*(int*)BDPORT_INTR = 0xF0000000;*/
	
	
	
	/////////////////////////
	//  				   //
	//  Configure the PIC  //
	//			           //
	/////////////////////////
	
	*(char*)PIC_MASK = 0xF0; // Enable the last bits as interrupts (1111 0000)
	
	
	char* bdp_data = (char*)BDPORT_DATA;

	//__asm__("ecall");
	
	int a = 10;

	do
	{
		//char b = bdp_data[0];
		//i++;
		
		int b = BDPort_Read();
		
		a *= count;
		
		*(int*)BDPORT_DATA = b << 28;
		
		count += 0x12;
		
	} while(1);
		
	return 1;
}