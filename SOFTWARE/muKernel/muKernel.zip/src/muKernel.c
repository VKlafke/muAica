#include "muKernel.h"



int trap_handler(int mcause, int mepc, int a0, int a1, int a2) 
{                                                                                          
    
    volatile char extern_int = 0, internal_int = 0;    
                                                                                                                 
    if (mcause >= 0) 
	{   
        //internal_int = 1;   // System calls and exceptions
		
		
		if(mcause == 4)// Misaligned data address
		{		
			__asm__ volatile 
			("li	x24,'E'\n\t" \
			 "li	x25,'X'\n\t" \
			 "li 	x26,'C'\n\t" \
			 "li	x27, 'E'\n\t" \
			 "li 	x28,'P'\n\t" \
			 "li 	x29,'T'\n\t" \
			 "li 	x30,'_'\n\t" \
			 "li 	x31,'4'\n\t");
			 
			return mepc;
		}
		else if(mcause == 8) // ECALL instruction
		{
			int ecall_func = 0;
			int retVal = 0;
			
			// Request ecall func ID is stored in a7 
			__asm__ volatile 
			(
				"mv %0, a7"
				: "=r" (ecall_func)
			);
			
			// Do the system call 
			
			if(ecall_func == 10) // BDPort config
			{		
				Kernel_BDPort_Setup(a0, a1, a2);
			}
			else if(ecall_func == 11) // BDPort read
			{
				retVal = Kernel_BDPort_Read();
			}
			
			// Put retval in register a1 (a0 is return to mepc)			
			__asm__ volatile
			(
				"mv a1, %0\n\t" 
				:
				: "r" (retVal)      
				: "a1"          
			);
			
			// DEBUG STRING, SIMULATION ONLY
			__asm__ volatile 
			("li	x24,'E'\n\t" \
			 "li	x25,'C'\n\t" \
			 "li 	x26,'A'\n\t" \
			 "li	x27, 'L'\n\t" \
			 "li 	x28,'L'\n\t" \
			 "li 	x29,'_'\n\t" \
			 "mv 	x30,%0\n\t" \
			 "li 	x31,''\n\t"
			 :
			 : "r"(ecall_func)
			 );		
			 
			 int mstatus_val = 128;
			 
			 __asm__ volatile 
			(
				"csrs mstatus, %0"
				:
				: "r" (mstatus_val)
			); // re-set mstatus, so mret enables it correctly on return.
		}
		
        return mepc + 4; // Return execution at the next inst 
    }
    else 
	{                                                                                                 
        //extern_int = 1;     // IRQs from PIC  
		
		ext_intr_handler();
		
        return mepc;
    }        
                                                                                                      
}

void ext_intr_handler()
{
	// Get IRQ number from PIC
	int IRQ_ID = *(char*)PIC_IRQ_ID;
	
	// Treat IRQ based on ID
	
	if(IRQ_ID == 7)
	{
		__asm__ volatile 
		("li	x24,''\n\t" \
		 "li	x25,''\n\t" \
		 "li 	x26,''\n\t" \
		 "li	x27, ''\n\t" \
		 "li	x28,'O'\n\t" \
		 "li	x29,'K'\n\t" \
		 "li 	x30,'_'\n\t" \
		 "li	x31, '7'\n\t");
	}
	else if(IRQ_ID == 6)
	{
		__asm__ volatile 
		("li	x24,''\n\t" \
		 "li	x25,''\n\t" \
		 "li 	x26,''\n\t" \
		 "li	x27, ''\n\t" \
		 "li	x28,'O'\n\t" \
		 "li	x29,'K'\n\t" \
		 "li 	x30,'_'\n\t" \
		 "li	x31, '6'\n\t");
	}
	
	// Notify PIC that IRQ was treated
	
	*(char*)PIC_ACK = IRQ_ID;
	
}

//////////////////////////////
//
//	BDPort system functions
//

// Set up BD port registers
// Config: Bit is input / output
// Enable: Bit is enabled
// 	 Intr: Bit is interruption (only bits 31 - 24)
void Kernel_BDPort_Setup(int config, int enable, int intr)
{
	*(int*)BDPORT_CFG = config;
	*(int*)BDPORT_EN = enable;
	*(int*)BDPORT_INTR = intr;
	
	return;
}

// Read int value from BDPort
int Kernel_BDPort_Read()
{
	int ret = *(int*)BDPORT_DATA;
	
	return ret;
}



							//
							//
							//
//////////////////////////////